﻿// FOR ALL --------------------------

function logout() {
  if(confirm("logout?")) {
    window.location.href = "info.php?logout";
  }
}

function count_cart() {
  $.ajax({
    type: "GET",
    url: "cc_basket.php?cart_count",
    success: function (msg) {
      $("#cartcount,#cart_count_cards").text(msg);
    }
  });
}

function balance() {
  $.ajax({
    type: "GET",
    url: "info.php?get_balance",
    success: function (msg) {
      $("#balance").text(msg);
    },
    error: function () {
      setTimeout(function () {
        balance();
      }, 5000);
    }
  });
}

//___________________________________

// LOGIN --------------------------
$("#signin").on("click", function () {
  sign_in();
});

function sign_in() {
  var user = $("#username").serialize();
  var pass = $("#password").serialize();
  $.ajax({
    type: "POST",
    url: "login.php?login",
    data: user + "&" + pass,
    beforeSend: function () {
      $('#signin').text('...');
    },
    success: function (result) {
      if(result === '5') {
        window.location = "/index.php";
      }
      if(result === '3') {
        alert('no such account exists');
      }
      if(result === '0') {
        alert('many requests by ip');
      }
      if(result === '1') {
        alert('many requests by username');
      }
    },
    complete: function () {
      $("#signin").text("Sign In");
    }
  });
}

//___________________________________

// REGISTRATION ---------------------
function register() {
  $.ajax({
    dataType: 'json',
    type: "POST",
    url: "login.php?register",
    beforeSend: function () {
      $('#register_modal').modal('show');
    },
    success: function (result) {
      if(result.register === 'ok') {
        $('#generated_username').text(result.username);
        $('#generated_password').text(result.password);
        $('#username').val(result.username);
        $('#password').val(result.password);
      }
    }
  });
}

//___________________________________

// BIN     --------------------------
function clearbintext() {
  $('#mybins').val('');
}

function bin_search() {
  $.ajax({
    dataType: "json",
    type: 'post',
    url: 'bin_search.php?bininfo',
    data: 'data=' + $('#mybins').val(),
    beforeSend: function () {
      $('#bininfo').addClass('loading');
      $('#bintext').html('');
    },
    success: function (result) {
      if(result.length > 0) {
        $.each(result, function (c, d) {
          $('#bintext').append('<tr>' +
            '<td>' + d.bin + '</td>' +
            '<td>' + d.country + '</td>' +
            '<td>' + d.depart + '</td>' +
            '<td>' + d.brand + '</td>' +
            '<td>' + d.type + '</td>' +
            '<td>' + d.level + '</td>' +
            '</tr>');
        });
      }
    },
    complete: function () {
      $('#bininfo').removeClass('loading');
    }
  });
}

//___________________________________

// BUY CC     --------------------------
function insert_list(type, result) {
  $.each(result, function (ind, item) {
    if(type === 'category') {
      if(item.date === '0000-00-00' || item.date === '--') {
        item.date = '';
      }

      $('#categoryid').append('<option value="' + item.id + '"> ['+item.valtextname+']  ' + item.date + ' ' + item.value + ' (' + item.catcounti + ' ccs)</option>');
    }
    if(type === 'country') {
      $('#cardcountry').append('<option value="' + item.id + '">' + item.value + ' (' + item.coucounti + ' ccs)</option>');
    }
    if(type === 'brand' || type === 'type' || type === 'city' || type === 'state') {
      $('#card' + type).append('<option value="' + item.id + '">' + item.value + '</option>');
    }
  });
}

function get_list(index, name, path, disabled = '') {

  var form_info = {
    selltype: $('#selltype').val(), cvv: $('#cardcvv').val(),
    category: $('#categoryid').val(), country: $('#cardcountry').val(),
    brand: $('#cardbrand').val(), type: $('#cardtype').val(),
    bin: $('#cardbin').val(), state: $('#cardstate').val(),
    city: $('#cardcity').val(), zip: $('#cardzip').val()
  };
  var data = $.param(form_info);

  $.ajax({
    dataType: "json",
    async: true,
    type: 'post',
    url: 'cc_buy.php?' + path,
    data: data,
    beforeSend: function () {
      $('#' + index + ' *').remove();
      $('#' + index).html('<option selected disabled>wait loading</option>');
    },
    success: function (result) {
      $('#' + index + ' *').remove();
      $('#' + index).html('<option selected ' + disabled + '>' + name + '</option>');
      insert_list(path, result);
    },
    error: function () {
      $('#' + index + ' *').remove();
      setTimeout(function () {
        get_list(index, name, path);
      }, 5000);
    },
    complete: function () {
    }
  });
}

function change_category() {
  $('#cardbrand *,#cardtype *,#cardstate *,#cardcity *').remove();
  $('#cardbrand,#cardtype,#cardstate,#cardcity').html('<option selected disabled>Select other parameters for activate this field</option>');
  get_list('cardcountry', 'All countries', 'country');
  $('#searchbutton').removeClass('disabled');
}

function change_country() {
  $('#cardbrand *,#cardtype *,#cardstate *,#cardcity *').remove();
  $('#cardbrand,#cardtype,#cardstate,#cardcity').html('<option selected disabled>Select other parameters for activate this field</option>');

  if($('#cardcountry').val() !== '0' && $('#cardcountry').val() !== '') {
    get_list('cardbrand', 'All brands', 'brand');
    get_list('cardstate', 'All states', 'state');
  }
}

function change_brand() {
  $('#cardtype *,#cardstate *,#cardcity *').remove();
  $('#cardtype,#cardstate,#cardcity').html('<option selected disabled>Select other parameters for activate this field</option>');
  if($('#cardbrand').val() !== '') {
    get_list('cardtype', 'All levels', 'type');
    get_list('cardstate', 'All states', 'state');
  }
}

function change_type() {
  $('#cardstate *,#cardcity *').remove();
  $('#cardstate,#cardcity').html('<option selected disabled>Select other parameters for activate this field</option>');
  if($('#cardtype').val() !== '') {
    get_list('cardstate', 'All states', 'state');
  }
}

function change_state() {
  $('#cardcity *').remove();
  $('#cardcity').html('<option selected disabled>Select other parameters for activate this field</option>');

  if($('#cardstate').val() !== '') {
    get_list('cardcity', 'All cities', 'city');
  }
}

function textarea_change(vv, field) {
  if(vv === 'in') {
    $('#' + field).attr('rows', 7);
  }
  if(vv === 'out') {
    $('#' + field).attr('rows', 1);
  }
}

function view_card_list(page = 1) {
  var form_info = {
    page: page, category: $('#categoryid').val(),
    country: $('#cardcountry').val(),
    brand: $('#cardbrand').val(), type: $('#cardtype').val(),
    bin: $('#cardbin').val(), state: $('#cardstate').val(),
    city: $('#cardcity').val(), zip: $('#cardzip').val(), bank: $('#cardbank').val()
  };
  var data = $.param(form_info);
  $('#pageco').val(page);

  $.ajax({
    dataType: "json",
    type: 'post',
    url: 'cc_buy.php?cards',
    data: data,
    beforeSend: function () {
      $('#cardbody *').remove();
      $(".pageblock").css("display", "none");
    },
    success: function (result) {

      paginations(result[0]['count']);
      $(".pageblock").css("display", "");
      result.shift();
      $('#cardbody *').remove();
      if(result.length === 0) {
        tinfo('tbl_nocard', 'No info');
      }
      $.each(result, function (ind, item) {
        add_card_line(item);
      });
      $('#cardtable').removeClass('visually-hidden');
    },
    complete: function () {
    }
  });
}

function paginations(num) {
  if(num * 1 > 100) {
    num = 100;
  }
  let numpage = $('#pageco').val();
  let ddid = '';
  let ddidp = '';
  let prev = 1;
  let next = numpage * 1 + 1;
  if(numpage * 1 === 1) {
    prev = 1;
    ddidp = 'disabled';
  }
  if(next * 1 === num * 1) {
    ddid = 'disabled';
  }

  $('#pagmenu').html(
    '             <li class=" page-item ' + ddidp + '"><a class="page-link" onclick="view_card_list(' + prev + ')">Previous</a></li>\n' +
    '            <li class=" page-item"><a class="page-link">' + numpage + '</a></li>\n' +
    '            <li class=" page-item ' + ddid + '"><a class="page-link" onclick="view_card_list(' + next + ')">Next</a></li>');

}

function tinfo(name, text) {
  $('#cardbody').append('<tr id="' + name + '">\n' +
    '    <th colspan="14" style="text-align: center;">' + text + '</th>\n' +
    '</tr>');
}

function add_card_line(item) {
  if(item.catdate === '0000-00-00' || item.catdate === '--') {
    item.catdate = '';
  }
  if(item.city === '-NO-') {
    item.city = '--';
  }
  if(item.state === '-NO-') {
    item.state = '--';
  }
  if(item.zip === '-NO-') {
    item.zip = '--';
  }
  if(item.nocheckcc === '1') {
    item.nocheckcc = 'refundable';
  } else {
    item.nocheckcc = 'norefundable';
  }

  $('#cardbody').append('' +
    '<tr class="align-middle" id="card_line_' + item.id + '">\n' +
    '<td>' + item.bin + '<br><small>' + item.typecard + '</small></td>\n' +
    '<td>' + item.month + ' / ' + item.year + '</td>\n' +
    '<td>' + item.country + '<br> <small>' + item.bank + '<br>' + item.catdate + ' ' + item.catname + '</small></td>\n' +
    '<td>' + add_symbol(item.address) + '</td>\n' +
    '<td>' + item.city + '</td>\n' +
    '<td>' + item.state + '</td>\n' +
    '<td>' + item.zip + '</td>\n' +
    '<td>' + add_symbol(item.phone) + '</td>\n' +
    '<td>' + add_symbol(item.email) + '</td>\n' +
    '<td>' + item.price + '$<br>' + item.nocheckcc + '</td>\n' +
    '<td>' +
    '<div class="btn-group align-middle btn-sm" role="group" aria-label="">\n' +
    '      <button   id="but_' + item.id + '" onclick="to_cart(' + item.id + ')" type="button" class="btn btn-dark">Add to Cart</button>\n' +
    '    </div>' +
    '</td>\n' +
    '</tr>');
}

function add_symbol(id) {
  if(id === '1') {
    return '+';
  }
  if(id === '0') {
    return '--';
  }
  if(id === '2') {
    return '--';
  }
}

function to_cart(id) {
  $.ajax({
    dataType: "json",
    type: 'post',
    url: 'cc_basket.php?to_cart',
    data: 'cardid=' + id,
    success: function (result) {
      set_cart_status(result, id)
    },
    error: function () {
    }
  });
}

function set_cart_status(status, id) {
  if(status.toString() === '0') {
    $("#but_" + id).text('incart');
  }
  if(status.toString() === '1') {
    count_cart();
    $("#but_" + id).text('added');
  }
  if(status.toString() === '2') {
    $("#but_" + id).text('sold');
  }
}

function set_cart_status2(status, id) {
  if(status.toString() === '0') {
    $("#qbut_" + id).text('error');
  }
  if(status.toString() === '3') {
    count_cart();
    $("#qbut_" + id).text('bought');
  }
  if(status.toString() === '2') {
    $("#qbut_" + id).text('low balance');
  }
}

function quick_buy(id) {
  $.ajax({
    dataType: "json",
    type: 'post',
    url: 'cc_buy.php?buy_one',
    data: 'cardid=' + id,
    success: function (result) {
      balance();
      if(result === 3) {
        set_cart_status2(result, id);
        quick_buy_info(id);
      } else {
        $('#staticBackdroplw').modal('show');
      }
    },
    error: function () {
    }
  });
}

function quick_buy_info(id) {
  $.ajax({
    dataType: "json",
    type: 'get',
    url: 'cc_buy.php?get_card_data=' + id,
    success: function (result) {
      if(result[0].data) {
        $('#quicktext').text(result[0].data);
        $('#quickbuy_mod').modal('show');
      } else {
        set_cart_status2(0, id);
      }
    },
    error: function () {
    }
  });
}

//___________________________________

// CART     --------------------------
function view_cart_list() {
  $.ajax({
    dataType: "json",
    type: 'get',
    url: 'cc_basket.php?cart_card_list',
    beforeSend: function () {
    },
    success: function (result) {
      result.shift();
      $('#cardbody *').remove();
      if(result.length === 0) {
        tinfo('tbl_nocard', 'empty');
      }
      $.each(result, function (ind, item) {
        add_card_line_cart(item);
      });
    },
    complete: function () {
    }
  });
}

function add_card_line_cart(item) {
  if(item.catdate === '0000-00-00' || item.catdate === '--') {
    item.catdate = '';
  }
  if(item.city === '-NO-') {
    item.city = '--';
  }
  if(item.state === '-NO-') {
    item.state = '--';
  }
  if(item.zip === '-NO-') {
    item.zip = '--';
  }
  if(item.nocheckcc === '1') {
    item.nocheckcc = 'refundable';
  } else {
    item.nocheckcc = 'norefundable';
  }


  $('#cardbody').append('' +
    '<tr id="card_line_' + item.id + '">\n' +
    '<td>' + item.bin + '</td>\n' +
    '<td>' + item.month + '|' + item.year + '</td>\n' +
    '<td>' + item.country + '<br> <small>' + '' + item.catdate + ' ' + item.catname + '</small></td>\n' +
    '<td>' + add_symbol(item.address) + '</td>\n' +
    '<td>' + item.city + '</td>\n' +
    '<td>' + item.state + '</td>\n' +
    '<td>' + item.zip + '</td>\n' +
    '<td>$' + item.price + '<br>' + item.nocheckcc + '</td>\n' +
    '<td>' +
    '  <button class="btn btn-outline-secondary btn-sm" onclick="del_card(' + item.id + ')">delete</button>\n' +
    '</td>\n' +
    '</tr>');

}

function del_card(idcard) {
  $.ajax({
    type: 'post',
    url: 'cc_basket.php?del_card',
    data: 'id=' + idcard,
    success: function () {
      view_cart_list();
      get_cart_price();
      count_cart();
    },
    error: function () {
      setTimeout(function () {
        del_card(idcard);
      }, 5000);
    }
  });
}

function del_cart() {
  $.ajax({
    type: 'get',
    url: 'cc_basket.php?clear_cart',
    success: function () {
      $('#cardbody *').remove();
      count_cart();
      get_cart_price();
    },
    error: function () {
      setTimeout(function () {
        del_cart();
      }, 5000);
    }
  });
}

function get_cart_price() {
  $.ajax({
    dataType: "json",
    type: 'get',
    url: 'cc_basket.php?get_cart_price',
    success: function (result) {
      $('#cart_price_cards').text(result);
    },
    error: function () {
      $('#cart_price_cards').text('0');
      setTimeout(function () {
        get_cart_price();
      }, 5000);
    }
  });
}

function buy_card() {
  $.ajax({
    type: 'get',
    url: 'cc_basket.php?buy',
    success: function (result) {
      $('#cardbody *').remove();

      if(result === '1') {
        tinfo('tbl_nocard', 'no cards');
      }
      if(result === '2') {
        tinfo('tbl_balance_low', 'check balance');
      }
      if(result === '3') {
        tinfo('tbl_buy', 'bought cards');
        setTimeout(function () {
          window.location = 'cc_list.php';
        }, 500);
      }
      if(result === '' || result === '7') {
        tinfo('tbl_error', 'reload page');
      }
      balance();
      count_cart();
    },
    error: function () {
      $('#cardbody *').remove();
      setTimeout(function () {
        buy_card();
      }, 5000);
    }
  });
}

//___________________________________

// CCLIST     --------------------------
function hideoffone(cid) {
  $.ajax({
    type: 'get',
    url: 'cc_list.php?seecc=' + cid,
    success: function () {
      get_card_one(cid, 1);
    },
    error: function () {
      setTimeout(function () {
        hideoffone(cid);
      }, 2000);
    }
  });
}

function get_card_one(cid) {
  $.ajax({
    type: 'get',
    dataType: "json",
    url: 'cc_list.php?get_card=' + cid,
    beforeSend: function () {
      $('#cc_status_' + cid).text('--');
    },
    success: function (result) {
      card_line_set('', result[0]);
    },
    error: function () {
      $('#card_line_' + cid).html('<td colspan="3"><div class="text-center">error</div></td>');
      setTimeout(function () {
        get_card_one(cid);
      }, 3000);
    }
  });
}

function card_line_set(baid = '', itemdata, type = 1) {
  let HDATA;
  let trtrf = '', trtrb = '';
  if(type === 2) {
    trtrf = '<tr id="card_line_' + itemdata['id'] + '">';
    trtrb = '</tr>';
  }
  HDATA = trtrf + '<td class="text-center">' + itemdata['id'] + '</td>\n' +
    '<td class="text-start">' + itemdata['data'] + '</td>\n' +
    '<td class="text-end">\n' + get_card_buttons(itemdata) + '</td>' + trtrb;

  if(type === 2) {
    $('#ccday_' + baid).append(HDATA);
  } else {
    $('#card_line_' + itemdata['id']).html(HDATA);
  }
}

function get_card_buttons(itemdata) {
  let see_onclick, see_id, see_name, see_dis, stt_onclick, stt_id, stt_name, stt_dis = '';

  if(itemdata['hide'] === '0') {
    see_onclick = 'onclick="hideoffone(' + itemdata['id'] + ')"';
    see_id = 'id="seecc_' + itemdata['id'] + '"';
    see_name = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-unlock" viewBox="0 0 16 16">\n' +
      '  <path d="M11 1a2 2 0 0 0-2 2v4a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h5V3a3 3 0 0 1 6 0v4a.5.5 0 0 1-1 0V3a2 2 0 0 0-2-2zM3 8a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1H3z"/>\n' +
      '</svg>';
  } else {
    see_onclick = '';
    see_id = '';
    see_name = '';
    see_dis = 'disabled';
  }

  if(itemdata['ch_st'] === '0' && itemdata['fst'] === '0') {
    stt_onclick = 'onclick="send_to_check(' + itemdata['id'] + ')"';
    stt_id = '';
    stt_name = 'Check';
    //see_dis='disabled';
  }
  if(itemdata['ch_st'] === '1' && itemdata['fst'] === '0') {
    stt_onclick = 'onclick="get_card_one(' + itemdata['id'] + ')"';
    stt_id = 'id="cc_status_' + itemdata['id'] + '"';
    stt_name = 'Checking';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '2' && itemdata['fst'] === '0') {
    stt_onclick = 'onclick="get_card_one(' + itemdata['id'] + ')"';
    stt_id = 'id="cc_status_' + itemdata['id'] + '"';
    stt_name = 'Checking';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '1') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Valid';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '2') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Decline';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '3') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Refund';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '4') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Decline';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '0' && itemdata['fst'] === '5') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Notime';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '6') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Decline';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '7') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Decline';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '8') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Fail';
    stt_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '9') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Fail';
    stt_dis = 'disabled';
  }
  if(itemdata['ch_st'] === '3' && itemdata['fst'] === '10') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Fail';
    stt_dis = 'disabled';
  }
  if(itemdata['fst'] === '11') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Refund';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }
  if(itemdata['fst'] >= '12' && itemdata['fst'] <= '18') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'TicketClose';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }

  if(itemdata['ch_st'] === '0' && itemdata['refund'] === '2') {
    stt_onclick = '';
    stt_id = '';
    stt_name = 'Noref';
    stt_dis = 'disabled';
    see_dis = 'disabled';
  }

  return '    <div class="btn-group" role="group" aria-label="">' +
    '<button class="btn btn-secondary ' + stt_dis + '" ' + stt_id + ' ' + stt_onclick + '>' + stt_name + '</button>' +
    '<button class="btn btn-secondary ' + see_dis + '" ' + see_id + ' ' + see_onclick + '>' + see_name + '</button>' +
    '</div>';
}

function send_to_check(id) {
  $.ajax({
    type: 'get',
    url: 'cc_list.php?to_check=' + id,
    success: function (result) {
      get_card_one(id);
      if(result === '1') {
        $('#lowbal').modal('show');
      }
    },
    error: function () {
      setTimeout(function () {
        send_to_check(id);
      }, 3000);
    }
  });
}

function update_daycc(daycc) {
  $.ajax({
    dataType: 'json',
    type: 'get',
    url: 'cc_list.php?get_daycc=' + daycc,
    beforeSend: function () {
      $('#upd_' + daycc).addClass('disabled');
    },
    success: function (result) {
      $('#ccday_' + daycc).html('');
      update_dayblock(daycc, result)
      balance();
    },
    complete: function () {
      $('#upd_' + daycc).removeClass('disabled');
    },
    error: function () {
      setTimeout(function () {
        get_basket(daycc);
      }, 5000);
    }
  });
}

function update_dayblock(cid, data) {
  $.each(data, function (inddata, itemdata) {
    card_line_set(cid, itemdata, 2);
  });

}
//___________________________________

// REPORTS  --------------------------
function mh_report(id,type) {
  var link;

  if(type === 'card') {
    link = 'cc_list';
  }
  $.ajax({
    type: 'get',
    url:  'cc_list.php?rtid=' + id + '&service=' + type,
    success: function (result) {
      $('#ticid').text(id);
      $('#report_text').text(result);
      $('#add_report').modal('show');
    }
  });
}


// ADDMONEY--------------------------
function payment_create(type) {
  $.ajax({
    dataType: "json",
    type: 'get',
    url: 'money.php?type=' + type,
    beforeSend: function () {
      $('#pay_load_' + type).removeClass('visually-hidden');
    },
    success: function (item) {
      if (item.error === 'noadr') {
        alert('Wait 5 min and try again!');
      }else if (item.error === 'limitaddr'){
        alert('You have unused address, use it. ');
      } else {
        if (item.details !== undefined) {
          $('#pay_data_' + type).html(
              '<tr>\n' +
              '        <td class="text-end">COIN:</td>\n' +
              '        <td>' + item.type + '</td>\n' +
              '      </tr>' +
              '<tr>\n' +
              '        <td class="text-end">Wallet:</td>\n' +
              '        <td>' + item.details + '</td>\n' +
              '      </tr>');
          $('#pay_block_' + type).removeClass('visually-hidden');

        } else {
          alert('The payment merchant is not working. Try again later.');
        }
        $('#pay_load_' + type).addClass('visually-hidden');
      }
    },
    complete: function () {
      $('#pay_load_' + type).addClass('visually-hidden');
    }
  });
}

function get_history(type) {
  $.ajax({
    dataType: "json",
    type: 'get',
    url: 'money.php?history=' + type,
    beforeSend: function () {
      $('#history_load_' + type).removeClass('visually-hidden');
    },
    success: function (item) {
      $('#history_data_' + type).html('');
      $.each(item, function (inddata, itemdata) {
        let button_check='';
        if (itemdata.status==='opened'){itemdata.status='wait payment';}
        if (itemdata.status==='confirmed'){itemdata.status='received';}

        $('#history_data_' + type).append(
        '<tr class="text-center">' +
        '     <th class="">'+itemdata.id+'</th>' +
        '     <th class="">'+itemdata.date+'</th>' +
        '     <th class="">'+itemdata.details+'</th>' +
        '     <th class="">$'+itemdata.balance+'</th>' +
        '     <th class="">'+itemdata.status+'</th>' +
        '   </tr>');

      });

      $('#history_block_' + type).removeClass('visually-hidden');
      $('#history_load_' + type).addClass('visually-hidden');
    },
    complete: function () {
      $('#history_load_' + type).addClass('visually-hidden');
    }
  });
}




































































































































































































